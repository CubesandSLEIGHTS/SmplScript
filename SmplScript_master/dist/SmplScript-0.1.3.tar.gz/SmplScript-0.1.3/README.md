# SmplScript: A Beginner's Programming Language

### What is SmplScript?

SmplScript is an interpreted scripting language. It is meant for the people who don't know how to program, but want to start. 

---

### What is a programming language?

A programming language is a notation for writing programs, which are specifications of a computation or algorithm. 

---

### Why should I use this language?

SmplScript is a very easy to use language. The syntax is based out of English.

---
### How do I use the language?

Go to [HERE](https://github.com/CubesandSLEIGHTS/SmplScript/blob/master/SmplScript/SmplScript_Tutorial.md "SmplScript Tutorial") for a tutorial.
